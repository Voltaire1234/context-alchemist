import { useState } from "react";

export default function ContextAlchemist() {
  const [inputText, setInputText] = useState("");
  const [outputText, setOutputText] = useState("");
  const [mode, setMode] = useState("nlpToJson");

  const extractJson = (prompt) => {
    const subjectMatch = prompt.match(/a[n]?\s+(\w+)/i);
    const subject = subjectMatch ? subjectMatch[1] : "unknown";

    const actionMatch = prompt.match(/\b(running|flying|hovering|sitting|walking|jumping|swimming|dancing)\b/i);
    const action = actionMatch ? actionMatch[1] : "unspecified";

    const envMatch = prompt.match(/in\s+(a[n]?\s+)?(.+?)(,|\.|with)/i);
    const environment = envMatch ? envMatch[2] : "unspecified";

    const angleMatch = prompt.match(/(close-up|wide|side|top|aerial)/i);
    const motionMatch = prompt.match(/(slow motion|smooth pan|fast|steady)/i);
    const styleMatch = prompt.match(/(cinematic|dreamy|realistic|soft|dramatic)/i);

    const result = {
      subject: subject.charAt(0).toUpperCase() + subject.slice(1),
      action,
      environment,
      camera: {
        angle: angleMatch ? angleMatch[1] : "default",
        motion: motionMatch ? motionMatch[1] : "static",
      },
      style: styleMatch ? styleMatch[1] : "standard",
    };

    return JSON.stringify(result, null, 2);
  };

  const jsonToPrompt = (jsonStr) => {
    try {
      const data = JSON.parse(jsonStr);
      const subject = data.subject || "Something";
      const action = data.action || "exists";
      const environment = data.environment || "an undefined space";
      const angle = data.camera?.angle || "default";
      const motion = data.camera?.motion || "static";
      const style = data.style || "standard";

      return `A ${subject.toLowerCase()} ${action} in ${environment}, captured in a ${style} style with a ${angle} angle and ${motion} camera motion.`;
    } catch (e) {
      return "Invalid JSON input.";
    }
  };

  const handleConvert = () => {
    const output = mode === "nlpToJson" ? extractJson(inputText) : jsonToPrompt(inputText);
    setOutputText(output);
  };

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Ding-Dong’s Context Alchemist</h1>
      <div className="flex space-x-2">
        <button onClick={() => setMode("nlpToJson")} className={`px-3 py-1 ${mode === "nlpToJson" ? "bg-blue-500 text-white" : "bg-gray-200"}`}>🧠 NLP ➜ JSON</button>
        <button onClick={() => setMode("jsonToNlp")} className={`px-3 py-1 ${mode === "jsonToNlp" ? "bg-blue-500 text-white" : "bg-gray-200"}`}>🪄 JSON ➜ Prompt</button>
      </div>
      <textarea rows={6} value={inputText} onChange={(e) => setInputText(e.target.value)} placeholder={mode === "nlpToJson" ? "Enter a natural prompt..." : "Enter a JSON object..."} className="w-full border p-2" />
      <button onClick={handleConvert} className="px-4 py-2 bg-green-600 text-white">✨ Convert</button>
      <pre className="p-4 bg-gray-100 rounded-xl whitespace-pre-wrap">{outputText || "Output will appear here..."}</pre>
    </div>
  );
}